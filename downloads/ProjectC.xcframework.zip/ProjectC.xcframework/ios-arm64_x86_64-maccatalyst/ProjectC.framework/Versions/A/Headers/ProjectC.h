//
//  ProjectC.h
//  ProjectC
//
//  Created by Artashes.Egiazaryan on 02.02.25.
//

#import <Foundation/Foundation.h>

//! Project version number for ProjectC.
FOUNDATION_EXPORT double ProjectCVersionNumber;

//! Project version string for ProjectC.
FOUNDATION_EXPORT const unsigned char ProjectCVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ProjectC/PublicHeader.h>

#import <ProjectC/CLogger.h>
