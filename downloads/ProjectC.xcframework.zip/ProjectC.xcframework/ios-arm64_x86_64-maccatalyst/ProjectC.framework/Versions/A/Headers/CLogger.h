//
//  CLogger.h
//  
//
//  Created by Artashes.Egiazaryan on 02.02.25.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CLogger : NSObject

-(void) functionC;

@end

NS_ASSUME_NONNULL_END
